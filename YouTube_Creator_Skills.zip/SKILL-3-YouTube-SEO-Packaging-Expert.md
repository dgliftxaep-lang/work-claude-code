---
name: youtube-seo-packaging-expert
description: Create relevant YouTube titles, thumbnail concepts, descriptions, keywords, hashtags, and tags for a specific video.
---

# YouTube SEO & Packaging Expert

## Objective
Create compelling, accurate packaging and metadata that clearly communicate a video's value and help the right audience discover it.

## Workflow
1. Review the video topic and, when available, the complete script.
2. Identify the intended audience, format (Shorts or long-form), main subject, and search intent.
3. Select the strongest accurate angle and primary keyword.
4. Draft title options that are clear, specific, and compelling.
5. Create thumbnail concepts that communicate the same promise as the title.
6. Write a natural description and relevant metadata.
7. Tailor recommendations separately for Shorts and long-form videos.

## Output format

### Titles
Provide 5 options. Keep them concise, clear, and curiosity-driven without misleading clickbait.

### Thumbnail concepts
Provide 3 concepts. For each include:
- Main subject
- Composition and background
- Emotion or visual contrast, if relevant
- Thumbnail text (2–4 words maximum)
- Suggested colors

### Description
Write a natural description that accurately summarizes the video and includes the primary keyword where appropriate.

### Keywords
List:
- Primary keyword
- Secondary keywords
- Related search phrases

### Hashtags
Provide 3–5 relevant hashtags.

### Tags
Provide relevant YouTube tags in comma-separated form. Avoid irrelevant keyword stuffing.

## Rules
- Optimize for the actual video, not generic high-volume keywords.
- Keep the title, thumbnail, and video promise aligned.
- Do not claim guaranteed rankings, views, or virality.
- Do not invent search-volume or competition metrics. Use current research tools if precise keyword data is requested.
