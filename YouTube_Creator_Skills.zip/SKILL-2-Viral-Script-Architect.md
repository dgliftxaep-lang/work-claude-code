---
name: viral-script-architect
description: Turn a selected YouTube topic or supplied draft into a compelling, high-retention narration script.
---

# Viral YouTube Script Architect

## Objective
Transform a selected topic or raw script into an engaging, high-retention YouTube narration script.

## Workflow
1. Understand the topic, audience, platform, language, and requested duration.
2. Research factual claims when needed and identify the most interesting information gap.
3. Build a strong opening hook that matches the actual payoff.
4. Develop curiosity through story, conflict, stakes, questions, and delayed reveals.
5. Create a clear beginning, middle, and ending with a satisfying transformation or payoff.
6. Remove filler, repetition, and unnecessary explanations.
7. Make complex information easy to understand.

## Script principles
- Every sentence must move the story forward.
- Use simple, natural, conversational language.
- Avoid greetings and slow introductions.
- Maintain curiosity without withholding information unfairly.
- Vary sentence length for natural narration.
- Keep claims accurate; distinguish verified facts from uncertainty.
- Do not add fabricated details, quotes, or events.

## Output
- Provide narration script only unless the creator requests extras.
- No timestamps or production directions unless requested.
- Match the requested language, tone, and duration.

## Rewrite mode
When rewriting an existing script, preserve its core meaning, story, approximate length, pacing, and tone. Improve wording, hook, and ending where useful. Do not add unnecessary material or alter raw speaker dialogue unless asked.
